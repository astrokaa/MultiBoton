package com.example.multibotones;

import android.annotation.SuppressLint;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;

import androidx.appcompat.app.AppCompatActivity;

public class MainActivity extends AppCompatActivity {


    private int count1 = 0;
    private int count2 = 0;
    private int count3 = 0;
    private int count4 = 0;
    private TextView totalCount;

    @SuppressLint("MissingInflatedId")
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        TextView textViewCount1 = findViewById(R.id.Count1);
        TextView textViewCount2 = findViewById(R.id.Count2);
        TextView textViewCount3 = findViewById(R.id.Count3);
        TextView textViewCount4 = findViewById(R.id.Count4);
        totalCount = findViewById(R.id.TotalCount);

        Button button1 = findViewById(R.id.Button1);
        Button buttonReset1 = findViewById(R.id.Reset1);

        Button button2 = findViewById(R.id.Button2);
        Button buttonReset2 = findViewById(R.id.Reset2);

        Button button3 = findViewById(R.id.Button3);
        Button buttonReset3 = findViewById(R.id.Reset3);

        Button button4 = findViewById(R.id.Button4);
        Button buttonReset4 = findViewById(R.id.Reset4);

        Button buttonResetAll = findViewById(R.id.ResetAll);

        button1.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                count1++;
                textViewCount1.setText(String.valueOf(count1));
                updateTotalCount();
            }
        });

        buttonReset1.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                count1 = 0;
                textViewCount1.setText(String.valueOf(count1));
                updateTotalCount();
            }
        });

        button2.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                count2++;
                textViewCount2.setText(String.valueOf(count2));
                updateTotalCount();
            }
        });

        buttonReset2.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                count2 = 0;
                textViewCount2.setText(String.valueOf(count2));
                updateTotalCount();
            }
        });

        button3.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                count3++;
                textViewCount3.setText(String.valueOf(count3));
                updateTotalCount();
            }
        });

        buttonReset3.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                count3 = 0;
                textViewCount3.setText(String.valueOf(count3));
                updateTotalCount();
            }
        });

        button4.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                count4++;
                textViewCount4.setText(String.valueOf(count4));
                updateTotalCount();
            }
        });

        buttonReset4.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                count4 = 0;
                textViewCount4.setText(String.valueOf(count4));
                updateTotalCount();
            }
        });

        buttonResetAll.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                count1 = 0;
                count2 = 0;
                count3 = 0;
                count4 = 0;
                textViewCount1.setText(String.valueOf(count1));
                textViewCount2.setText(String.valueOf(count2));
                textViewCount3.setText(String.valueOf(count3));
                textViewCount4.setText(String.valueOf(count4));
                updateTotalCount();
            }
        });
    }

    private void updateTotalCount() {
        int total = count1 + count2 + count3 + count4;
        totalCount.setText(String.valueOf(total));
    }
}
